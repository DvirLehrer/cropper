from itertools import compress
from shapely.ops import unary_union
from PolygonData import *
from Utils.common_methods import debug_assert


class PolygonsList:
    def __init__(self):
        self.__data = list()  # list of polygons ( PolygonData instances)
        self.__count_polygons = 0  # size of __data
        self.__lines = {}
        self.__line_boundaries = None
        self.__even_odd_polygons = None

    # getters
    @property
    def data(self):
        return self.__data

    @property
    def valid_data(self):
        return [p for p in self.__data if p]

    @property
    def count_polygons(self):
        return self.__count_polygons

    @property
    def lines(self):
        return self.__lines

    @property
    def line_boundaries(self):
        if self.__line_boundaries is None:
            self.compute_line_boundaries()
        return self.__line_boundaries

    def add_polygon(self, scan_data, index, contours, bounds):
        '''

        @param index:
        @param cntr:
        @param bounds:  x1, y1, x2, y2
        @return:
        '''
        if index in range(0, self.__count_polygons):
            self.del_by_index(index)
            self.__data[index] = PolygonData(scan_data, index, contours, bounds)
        else:
            assert index == self.__count_polygons
            self.__data.append(PolygonData(scan_data, index, contours, bounds))
            self.__count_polygons += 1
        return self.__data[index]

    def get_by_index(self, index):
        if isinstance(index, list):
            return [self.get_by_index(i) for i in index]
        else:
            if index in range(0, self.__count_polygons):
                return self.data[index]
            else:
                return None

    def get_by_mask(self, mask):
        return compress(self.__data, mask)

    def del_by_index(self, index):
        if index in range(0, self.__count_polygons):
            polygon = self.__data[index]
            if polygon:
                for l in polygon.lines:
                    self.__lines[l].remove(polygon)
                    if not self.__lines[l]:
                        del self.__lines[l]
                        for line_num, line_polygons in self.__lines.items():
                            if line_num > l:
                                updated_line_num = line_num - 1
                                self.__lines[updated_line_num] = self.__lines.pop(line_num)
                                for p in line_polygons:
                                    p.lines.remove(l)
                                    p.lines.add(updated_line_num)
                self.__data[index] = None

    def set_polygon_lines(self, id, cur_lines):
        poly = self.get_by_index(id)
        cur_lines = set(cur_lines)
        old_lines = [x for x in poly.lines if x not in cur_lines]  # Get the lines that the poly_data no longer belongs to
        new_lines = [x for x in cur_lines if x not in poly.lines]  # Get the lines that the poly_data will be added to
        for l in old_lines:
            self.__lines[l].remove(poly)
        for l in new_lines:
            self.__lines.setdefault(l, []).append(poly)
        poly.set_lines(cur_lines)

    def union(self, index1, index2, inplace=True, scan_data=None):
        debug_assert(inplace or scan_data)
        poly1 = self.get_by_index(index1)
        poly2 = self.get_by_index(index2)

        if poly1 is None or poly2 is None:
            return None   # index already removed by an earlier union
        new_contours = poly1.contours + poly2.contours
        new_box = poly1.box.union(poly2.box).envelope
        new_sh_polygon = unary_union([geom for geom in [poly1.sh_polygon, poly2.sh_polygon] if geom.is_valid])
        new_sh_polygon = make_valid(new_sh_polygon)
        new_lines = poly1.lines.union(poly2.lines)

        if inplace:
            poly1.contours, poly1.box, poly1.sh_polygon = new_contours, new_box, new_sh_polygon
            poly1.reset_stats()
            self.set_polygon_lines(index1, new_lines)
            self.del_by_index(index2)
        else:
            new_idx = self.__count_polygons
            new_poly = self.add_polygon(scan_data, new_idx, new_contours, new_box.bounds)
            self.set_polygon_lines(new_idx, new_lines)
            # remember to delete poly1 and poly2 or new poly_data after
            return new_poly

    # function that separates the polygon to two polygons (opposite of union function)
    def split(self, index, inplace=False, scan_data=None):
        pass

    def compute_line_boundaries(self):
        num_lines = len(self.__lines.keys())
        self.__line_boundaries = np.zeros((num_lines, 2))
        self.__even_odd_polygons = np.zeros((2, self.__count_polygons), dtype=bool)
        self.__line_boundaries[:, 0] = np.inf

        for polygon_index, polygon in enumerate(self.__data):
            if polygon is None:
                continue
            if len(polygon.lines) == 0:
                continue
            _, y1, _, y2 = polygon.box.bounds
            for line_i in polygon.lines:
                self.__line_boundaries[line_i, 0] = min(self.__line_boundaries[line_i, 0], y1)
                self.__line_boundaries[line_i, 1] = max(self.__line_boundaries[line_i, 1], y2)
                self.__even_odd_polygons[line_i % 2, polygon_index] = True

    def get_even_odd_lines_contours(self):
        if self.__even_odd_polygons is None:
            self.compute_line_boundaries()

        def get_contours(even=True):
            i = 0 if even else 1
            return [cntr for x in self.get_by_mask(self.__even_odd_polygons[i]) for cntr in x.contours]

        return (get_contours(even=True), get_contours(even=False))

    def collect_spaces_info(self):
        spaces_in_all_lines = []
        num_lines = len(self.lines)
        for line in range(num_lines):
            polys = self.lines[line]
            polys.sort(key=lambda x: x.text_part.x + x.text_part.w, reverse=False)
            spaces_in_line = []
            # compute spaces between each two successive letters, save result in spaces_in_line
            for poly_data1, poly_data2 in zip(polys[:-1], polys[1:]):
                spaces_in_line.append(poly_data1.distance(poly_data2))  # todo: future feature: use "poly_data1.roof_distance(poly_data2)". before that - maybe use x distance only
            spaces_in_line = np.array([0] + spaces_in_line + [0])
            spaces_in_all_lines.append(spaces_in_line)
        return spaces_in_all_lines
