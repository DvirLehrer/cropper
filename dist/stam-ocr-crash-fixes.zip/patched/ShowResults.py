import difflib
import json
import os
import re

from hebrew_numbers import int_to_gematria

from ScanData import *
from TextPart import TextPart
from Utils.MyDiffLib import MyDiffLib
from Utils.common_methods import *
from parameters import *

import numpy as np
import zlib
import json
import base64


class ShowResults:
    @staticmethod
    def find_reference_text(scan_data: ScanData, abort_on_tora=False):
        """
        finds the original text, to be used as reference
        """
        cur_path = os.path.dirname(os.path.realpath(__file__))
        texts_base_path = cur_path + '/home/ubuntu/ocr/texts/'
        path_tora_245 = texts_base_path + "torah_densed_245.txt"
        path_tora_248 = texts_base_path + "248.txt"
        path_tora_yemini = texts_base_path + "yemini.txt"
        path_mezuza = texts_base_path + "mezuza.txt"
        path_kadesh =  texts_base_path + "kadesh.txt"
        path_vayaviecha =  texts_base_path + "vayaviecha.txt"
        path_shma =  texts_base_path + "shma.txt"
        path_shamoa =  texts_base_path + "shamoa.txt"
        sources_list = [path_mezuza, path_kadesh, path_vayaviecha, path_shma, path_shamoa, path_tora_245, path_tora_248, path_tora_yemini]
        sources_list_names = ["mezuza", "tefilin-kadesh", "tefilin-vayaviecha", "tefilin-shma", "tefilin-shamoa", "torah 245", "248", "yemini"]

        text_types = {1: "torah 245", 2: "mezuza", 3: "tefilin-kadesh", 4: "tefilin-shma", 5: "tefilin-vayaviecha", 6: "tefilin-shamoa", 7: "nach"}

        logging.debug("prep_txt start 1 " + str(time.time()))

        orig_text = ""
        page_num = 1
        page_num_heb = ""

        tried_to_default_from_path = False
        while orig_text == "":
            if ("torah" in scan_data.text_type):
                if abort_on_tora:
                    return False
                if "248" in scan_data.text_type:
                    with open(path_tora_248, encoding='utf-8') as f:
                        text_source = f.read()
                    torah_txt = text_source
                elif "yemeni" in scan_data.text_type:
                    with open(path_tora_yemini, encoding='utf-8') as f:
                        text_source = f.read()
                    torah_txt = text_source
                # if "245" in scan_data.text_type:
                else:
                    if not "245" in scan_data.text_type:
                        print("defaulting torah to 245")
                    with open(path_tora_245, encoding='utf-8') as f:
                        text_source = f.read()
                    torah_txt = text_source

                splitted_pages = re.split(r"\d+", torah_txt)
                torah_pages = [page for page in splitted_pages if len(page) > 2]
                close_matches = MyDiffLib.get_close_matches_indexes(scan_data.ocr_text_data.ocr_text, torah_pages, len(torah_pages), cutoff=0)

                if len(close_matches) == 0:
                    raise Exception("find_reference_text: couldn't find original text from torah")
                page_num = close_matches[0]
                orig_text = torah_pages[page_num]
                page_num_heb = int_to_gematria(page_num)
                words_list = orig_text.split()
            elif ("mezuza" in scan_data.text_type):
                # upload the mezuza text
                with open(path_mezuza, encoding='utf-8') as f:
                    text_source = f.read()
                orig_text = text_source

            elif ("tefilin" in scan_data.text_type):

                if "kadesh" in scan_data.text_type:
                    with open(path_kadesh, encoding='utf-8') as f:
                        text_source = f.read()
                    orig_text = text_source

                if "shma" in scan_data.text_type:
                    with open(path_shma, encoding='utf-8') as f:
                        text_source = f.read()
                    orig_text = text_source

                if "vayaviecha" in scan_data.text_type:
                    with open(path_vayaviecha, encoding='utf-8') as f:
                        text_source = f.read()
                    orig_text = text_source

                if "shamoa" in scan_data.text_type:
                    with open(path_shamoa, encoding='utf-8') as f:
                        text_source = f.read()
                    orig_text = text_source
            elif ("nach" in scan_data.text_type):  # we don't have nach, need to find text (in the internet?). note that there are different versions for megilat ester - Hamalech 21, Hamelech 26, Hamelech 42. something like that.
                # upload the megilut text
                with open(os.path.dirname(os.path.realpath(__file__)) + '/home/ubuntu/ocr/texts/megilut.txt',
                          encoding='utf-8') as f:
                    text_source = f.read()
                orig_text = text_source
            elif TEXT_TYPE_AUTO_DETECT:
                # toc("start auto detect text type")
                all_splitted_pages = []
                text_types_list = []
                found_source = False
                for i, path in enumerate(sources_list):
                    with open(path, encoding='utf-8') as f:
                        cur_ref_text = f.read()
                    splitted_pages = re.split(r"\d+", cur_ref_text)
                    splitted_pages = [page for page in splitted_pages if len(page) > 2]
                    initial_cutoff = 0.05  # this was 0.1 and was lowered to 0.05 to detect tfilin with outer noises faster
                    close_matches = MyDiffLib.get_close_matches_indexes(scan_data.ocr_text_data.ocr_text, splitted_pages, len(splitted_pages), cutoff=initial_cutoff)
                    cur_text_type = sources_list_names[i]
                    if len(close_matches) > 0:
                        # without this tfilin-shma detected as full mezuza (shma + vehaya) with cutoff of perfect 0!
                        if len(splitted_pages[close_matches[0]]) * 0.8 < len(scan_data.ocr_text_data.ocr_text) < len(splitted_pages[close_matches[0]]) * 1.2:
                            found_source = True
                            page_num = close_matches[0]
                            orig_text = splitted_pages[page_num]
                            page_num_heb = int_to_gematria(page_num)
                            scan_data.text_type = cur_text_type
                            break
                    all_splitted_pages += splitted_pages
                    text_types_list.extend([cur_text_type] * len(splitted_pages))  # todo - make sure this length works as planned for single and multi line refs
                if not found_source:
                    cutoff = 0
                    close_matches = MyDiffLib.get_close_matches_indexes(scan_data.ocr_text_data.ocr_text, all_splitted_pages, len(all_splitted_pages), cutoff=cutoff)
                    page_num = close_matches[0]
                    orig_text = all_splitted_pages[page_num]
                    scan_data.text_type = text_types_list[page_num]
                    if page_num > 4:
                        page_num = (page_num - 5) % 245 + 1
                    page_num_heb = int_to_gematria(page_num)
                # toc("end auto detect text type")
                break
            elif not tried_to_default_from_path:
                for text_type in text_types.values():
                    tt = text_type.split()[0]
                    if tt in scan_data.image_path.lower().split('\\'):
                        print(f"defaulting to setting origin text type to {tt} from path")
                        scan_data.text_type = tt
                tried_to_default_from_path = True
                continue
            elif DEFAULT_TYPE:
                assert DEFAULT_TYPE in text_types.values(), f"DEFAULT_TYPE not in text_types.values(): {text_types.values()}"
                scan_data.text_type = DEFAULT_TYPE
            else:
                h, w = scan_data.binary_img.shape
                debug_show("selected image", scan_data.binary_img)
                cv2.destroyAllWindows()
                msg = f"please choose text type (press number):{text_types.items()}"
                key = input(msg)
                scan_data.text_type = text_types[int(key)]
                print(f"text type is {scan_data.text_type}")

        orig_text = re.sub(r'[^-\s\u05D0-\u05EA]', '', orig_text)

        logging.debug("prep_txt 1 " + str(time.time()))

        scan_data.compare_data_module.reference_text = orig_text.strip().replace("  ", " " )  # todo handle space size in different parshiyot spacing )(פרשיה סתומה/פתוחה)
        scan_data.page_num = page_num
        scan_data.page_num_heb = page_num_heb

        logging.debug("prep_txt end 1 ")
        return True


    @staticmethod
    def generate_report(scan_data: ScanData):
        result_dict = {}
        if not OLD_SITE:
            result_dict = ShowResults.generate_new_scan_report(scan_data)
            if SHOW_ERRORS:
                img = scan_data.binary_img
                for line_i,line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
                    for word in line.sub_elements:
                        for letter in word.sub_elements:
                            if letter.error_type in {"ADDED_LETTER", "LETTER_SHAPE_CHANGED"}:
                                try:
                                    cv2.imshow("line", img[line.y:line.y + line.h, line.x:line.x + line.w])
                                    cv2.waitKey()
                                    cv2.imshow("word", img[word.y:word.y + word.h, word.x:word.x + word.w])
                                    cv2.waitKey()
                                    cv2.imshow("letter", img[letter.y:letter.y + letter.h, letter.x:letter.x + letter.w])
                                    cv2.waitKey()
                                except:
                                    pass
                            if letter.error_type is not None:
                                print(letter.error_type, letter.get_orig_text(line_i))
                                print(letter)
                                print(word)
                        cv2.destroyAllWindows()
        else:
            raise Exception("OLD_SITE is not supported")
            # result_dict = ShowResults.generate_old_scan_report(scan_data)
        scan_data.result_dict = result_dict
        return result_dict

    # @staticmethod
    # def generate_old_scan_report(scan_data):
    #
    #     def get_error_str(scan_data, word: TextPart, line_i):
    #         black_percentile_threshold = 95  # the closer this threshold is to 100 the fewer errors the chopper check will cancel (more touching letters warnings)
    #
    #         if word.error_type == "ADDED_WORD":
    #             error_str = f"{word.ocr_text}: מילה מיותרת"
    #
    #         elif word.error_type == "SWITCHED_WORD":
    #             error_str = f"{word.ocr_text}: מילה מוחלפת"
    #
    #         elif word.error_type == "MISSING_WORD":
    #             error_str = f"{word.get_orig_text()}: מילה חסרה"
    #
    #         elif word.error_type == "ALTERED_WORD":
    #             errors = []
    #             prev_style_change = False
    #             prev_letter_missing = False
    #             prev_letter = None
    #             for i, letter in enumerate(word.sub_elements):
    #                 if letter.error_type == "LETTER_SHAPE_CHANGED":  # "LETTER_SHAPE_CHANGED","ADDED_LETTER","MISSING_LETTER","TOUCHING_LETTER_H"
    #                     if prev_letter_missing:
    #                         chop_decision = word.sub_elements[i].poly_data and \
    #                                         scan_data.AnalyzeText.chop_polygon(scan_data, poly_list_index=word.sub_elements[i].poly_data.id, only_check_decision=True, min_gray_level_percentile_to_chop=black_percentile_threshold).chop_decision
    #                         if not chop_decision:
    #                             error_str = f"'{prev_letter}{letter.get_orig_text(line_i)}'חשש אותיות נוגעות "
    #                             errors.append(error_str)
    #                         prev_letter_missing = False
    #                     else:
    #                         error_str = f"'{letter.get_orig_text(line_i)}' בעיה בצורת האות"
    #                         errors.append(error_str)
    #                     prev_letter = letter.get_orig_text(line_i)
    #                     prev_style_change = True
    #
    #
    #                 elif letter.error_type == "ADDED_LETTER":
    #                     error_str = f"'{letter.ocr_text}' נוספה"
    #                     errors.append(error_str)
    #                 elif letter.error_type == "MISSING_LETTER":
    #                     width_near = 0
    #                     near_letter = ""
    #                     near_idx = 0
    #                     if i > 0 and word.sub_elements[i - 1].w is not None:
    #                         width_near = word.sub_elements[i - 1].w
    #                         near_letter = word.sub_elements[i - 1].get_orig_text(line_i)
    #                         near_idx = i - 1
    #                     if i < len(word.sub_elements) - 1 and word.sub_elements[i + 1].w is not None:
    #                         if word.sub_elements[i + 1].w > width_near:
    #                             width_near = word.sub_elements[i + 1].w
    #                             near_letter = word.sub_elements[i + 1].get_orig_text(line_i)
    #                             near_idx = i + 1
    #                     if prev_style_change:
    #                         chop_decision = word.sub_elements[i-1].poly_data and \
    #                                         scan_data.AnalyzeText.chop_polygon(scan_data, poly_list_index=word.sub_elements[i-1].poly_data.id, only_check_decision=True, min_gray_level_percentile_to_chop=black_percentile_threshold).chop_decision
    #                         if i > 0 and not chop_decision:
    #                             error_str = f"'{prev_letter}{letter.get_orig_text(line_i)}'חשש אותיות נוגעות "
    #                             errors.append(error_str)
    #                         prev_style_change = False
    #                     elif width_near > scan_data.avg_w * 1.5:
    #                         chop_decision = word.sub_elements[i - 1].poly_data and \
    #                                         scan_data.AnalyzeText.chop_polygon(scan_data, poly_list_index=word.sub_elements[i - 1].poly_data.id, only_check_decision=True, min_gray_level_percentile_to_chop=black_percentile_threshold).chop_decision
    #                         if i > 0 and not chop_decision:
    #                             if near_idx < i:
    #                                 error_str = f"'{near_letter}{letter.get_orig_text(line_i)}'חשש אותיות נוגעות "
    #                             else:
    #                                 error_str = f"'{letter.get_orig_text(line_i)}{near_letter}'חשש אותיות נוגעות "
    #                             errors.append(error_str)
    #                             prev_style_change = False
    #                     else:
    #                         error_str = f"'{letter.get_orig_text(line_i)}' חסרה"
    #                         errors.append(error_str)
    #                     prev_letter_missing = True
    #                 elif letter.error_type == "TOUCHING_LETTER_V":
    #                     error_str = f"'{letter.ocr_text}' נוגעת בשורה אחרת"
    #                     errors.append(error_str)
    #                 elif letter.error_type == "TOUCHING_LETTER_H":
    #                     error_str = f"'{letter.ocr_text}' חשש אותיות נוגעות"
    #                     errors.append(error_str)
    #                 elif letter.error_type == "MISSING_LETTER_OR_TOUCHING_LETTER_H":
    #                     error_str = f"'{letter.get_orig_text(line_i)}'אות חסרה או חשש אותיות נוגעות "
    #                     errors.append(error_str)
    #                 elif letter.error_type == "BROKEN_LETTER":
    #                     error_str = f"'{letter.get_orig_text(line_i)}'אות שבורה "
    #                     errors.append(error_str)
    #                     prev_style_change = True
    #                     prev_letter = letter.get_orig_text(line_i)
    #                 prev_letter = letter.get_orig_text(line_i)
    #             error_str = f"{word.get_orig_text()}:" + ','.join(errors)
    #
    #         if word.trailing_space is False:  # specifically false and not None
    #             error_str += "רווח חסר"
    #         return error_str
    #
    #     def get_highlight(word1: TextPart):
    #         result = ""
    #         for letter in word1.sub_elements:
    #             if letter.error_type is None:
    #                 result += '0'
    #             elif letter.error_type != "ADDED_LETTER" and letter.ocr_text!= " ":
    #                 result += '1'
    #         return result
    #
    #     def add_error(line_number, word_num, word: TextPart):
    #         error = {"wrong_word": word.ocr_text, "correct_word": word.get_orig_text(), "index_word": word_num,
    #                  "num_error_type": err_to_num_dict[word.error_type],
    #                  "string_error_type": word.error_type}
    #         if word.opcode_list is not None:
    #             error["opcode_list"] = word.opcode_list
    #         error_detail_dict.setdefault(line_number, []).append([error])
    #
    #     error_detail_dict = {}
    #     json_list_res = []
    #     json_dic = defaultdict(dict)
    #
    #     for line_i,line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
    #         error_string = ""
    #         errors_list = []
    #         highlights = ""
    #         for word_num, word in enumerate(line.sub_elements):
    #             highlight = get_highlight(word)
    #             highlights += highlight
    #             if word_num < len(line.sub_elements) - 1:
    #                 highlights += '0'
    #             if word.error_type is not None:
    #                 add_error(line.orig_index, word_num, word)
    #                 cur_error_string = get_error_str(scan_data, word, line_i)
    #                 error_string += cur_error_string + "\n"
    #                 errors_list.append(cur_error_string)
    #
    #         # create json
    #         key = line.orig_index
    #         json_dic[key]['user_id'] = scan_data.user_id
    #         json_dic[key]['session'] = scan_data.session_num
    #         json_dic[key]['text_type'] = scan_data.text_type
    #         json_dic[key]['time_stamp'] = scan_data.time_stamp
    #         json_dic[key]['page_word_first'] = 1  #
    #         json_dic[key]['page_word_last'] = 1  #
    #         json_dic[key]['page_number'] = scan_data.page_num
    #         json_dic[key]['page_num_heb'] = scan_data.page_num_heb
    #         json_dic[key]['line_number'] = key
    #         json_dic[key]['line_correct'] = line.get_orig_text()
    #         json_dic[key]['line_diff_result'] = ""
    #         json_dic[key]['errors_detail'] = error_detail_dict[key] if key in error_detail_dict else []
    #         json_dic[key]['errors_list'] = errors_list
    #         json_dic[key]['highlight'] = highlights
    #
    #         json_list_res.append(json_dic[key])
    #         ocrTextJson = {"line": key, "text": line.ocr_text}
    #         json_dump = json.dumps(ocrTextJson)
    #         scan_data.ocrTextArr.append(json_dump)
    #
    #     # will be removed if result key is unnecessary
    #     d = difflib.Differ()
    #     text_with_line_numbers = " ".join(f"{line.ocr_index} {line.ocr_text}" for line in scan_data.extended_ocr_text_data.sub_elements)
    #     reference_text = scan_data.compare_data_module.reference_text
    #     result = list(d.compare(reference_text.split(), text_with_line_numbers.split()))
    #
    #     result_dict = {"text_from_ocr": text_with_line_numbers, "result": json_list_res, "scriptImages": scan_data.cdnKeys, "lineImages": scan_data.lineImgArr, "ocrText": scan_data.ocrTextArr, "resultOrig": result, "orig_text": reference_text.split(), "text_from_ocrOrig": text_with_line_numbers, 'model': scan_data.model_to_run}
    #
    #     # for line in json_dic.values():
    #     #     if line:
    #     #         print(f"ref text: {line['line_correct']}")
    #     #         print(f"errors list: {line['errors_list']}")
    #     # raise Exception("debug run next")
    #
    #
    #
    #     # theJsonTwo={}
    #
    #     return result_dict

    @staticmethod
    def generate_new_scan_report(scan_data):

        result_dict = scan_data.extended_ocr_text_data.get_data_for_site(scan_data.polygons_data, test_mode=not OLD_SITE)
        result_dict["user_info"] = {"user_id": str(scan_data.user_id),
                                    "session": str(scan_data.session_num)}
        result_dict["report_info"] = {"report_url": "",
                                      "report_id": ""}

        result_dict["image1"] = scan_data.image_path
        result_dict["image2"] = scan_data.image_path
        result_dict["model"] = scan_data.model_to_run
        result_dict["width"] = scan_data.width
        result_dict["height"] = scan_data.height
        # pass the binary image to the site

        # image_as_str = '\n'.join(''.join(str(pixel // 255) for pixel in row) for row in scan_data.binary_img)
        image_as_list_of_lists = (scan_data.binary_img // 255).tolist()

        # compressed_data = zlib.compress(np.packbits(scan_data.binary_img // 255))
        # encoded_image = base64.b64encode(compressed_data).decode('utf-8')
        result_dict["binary_image"] = image_as_list_of_lists

        return result_dict

    @staticmethod
    def calc_mean_word_w(scan_data: ScanData):
        words_w = []
        for line in scan_data.extended_ocr_text_data.sub_elements:
            for word in line.sub_elements:
                if word.w is not None:
                    words_w.append(word.w)
        return np.mean(words_w)

    @staticmethod
    def estimate_all_missings_coordinates(scan_data: ScanData):
        """
        estimates the coordinates of missing words and letters, based on the coordinates of the surrounding words and letters
        """
        for line in scan_data.extended_ocr_text_data.sub_elements:
            average_word_w = None
            for word_i, word in enumerate(line.sub_elements):
                if word.error_type == "MISSING_WORD":
                    if average_word_w is None:
                        average_word_w = ShowResults.calc_mean_word_w(scan_data)
                    ShowResults.estimate_single_missing_textpart_coordinates(scan_data, word, word_i, line, average_word_w)
                else:
                    for letter_i, letter in enumerate(word.sub_elements):
                        if letter.poly_data is None:  # don't check for missing letters, as this can be changes with the touching letters heuristic
                        # if letter.error_type == "MISSING_LETTER_OR_TOUCHING_LETTER_H" or letter.error_type == "MISSING_LETTER":
                            ShowResults.estimate_single_missing_textpart_coordinates(scan_data, letter, letter_i, word, scan_data.typical_letter_w)



    @staticmethod
    def apply_touching_letters_H_heuristics_and_unite_coordinates(scan_data: ScanData):
        """
        connects first instance with all the rest of touching letters
        sets the coordinates to be coordinates the unison of the whole blob
        """
        for line in scan_data.extended_ocr_text_data.sub_elements:
            for word in line.sub_elements:
                in_h_touching_letters_blob = False
                blob_start = None
                touching_letter_heuristic = False
                prev_in_heuristic = False
                for letter_idx, letter in enumerate(word.sub_elements):
                    prev_in_heuristic = touching_letter_heuristic
                    touching_letter_heuristic = ((letter_idx < len(word.sub_elements) - 1) and
                                                ((letter.error_type == "LETTER_SHAPE_CHANGED" and word.sub_elements[letter_idx + 1].error_type == "MISSING_LETTER") or
                                                 (letter.error_type == "MISSING_LETTER" and word.sub_elements[letter_idx + 1].error_type == "LETTER_SHAPE_CHANGED")))
                    detected_touching = letter.error_type == "TOUCHING_LETTER_H"
                    cur_touching = detected_touching or touching_letter_heuristic or prev_in_heuristic
                    if not in_h_touching_letters_blob and cur_touching:
                        blob_start = letter_idx
                    if in_h_touching_letters_blob and not cur_touching:
                        ShowResults.handle_single_touching_letter_h(word, blob_start, letter_idx - 1)
                    in_h_touching_letters_blob = cur_touching
                # if loop ended inside touching letter:
                if in_h_touching_letters_blob:
                    ShowResults.handle_single_touching_letter_h(word, blob_start, len(word.sub_elements) - 1)

    @staticmethod
    def fix_l_swallowing(scan_data: ScanData):
        for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word_num, word in enumerate(line.sub_elements):
                for letter_idx, letter in enumerate(word.sub_elements):
                    if letter.error_type == "MISSING_LETTER":
                        right_letter = None
                        if letter_idx > 0:
                            right_letter = word.sub_elements[letter_idx - 1]
                        else:
                            if word_num > 0:
                                _prev = line.sub_elements[word_num - 1].sub_elements
                                right_letter = _prev[-1] if _prev else None
                            else:
                                right_letter = None

                        """
                        The idea: if we have missing letter and ל from right side, we want to check if it is really missing.
                        We check if ל consist from 2 contours. if so, we try to separate the polygon to 2 polygons
                        (in opposite way to union function) and run prediction again on each contour.
                        We {compare the entropy of the ל to average entropy of each contour and/or also} check if the
                        prediction of one of contours is ל and the second is the missing letter. If it is, we know that 
                        it's not a missing letter but the ל swallowed it during our process (probably in unite_parted_letters).
                        We also try to catch cases when the ל changed.
                        """

                        if right_letter is not None and right_letter.poly_data is not None and \
                                (right_letter.ocr_text == "ל" or right_letter.get_orig_text(line_num=line_num) == "ל"):
                            missing_letter = letter.get_orig_text(line_num=line_num)
                            l_poly = right_letter.poly_data
                            if len(l_poly.contours) == 2:
                                contours = l_poly.contours
                                contours_and_bounds = [(cnt, cv2.boundingRect(cnt)) for cnt in contours]
                                x_1, y_1, w_1, h_1 = contours_and_bounds[0][1]
                                x_2, y_2, w_2, h_2 = contours_and_bounds[1][1]
                                num_of_polygons = scan_data.polygons_data.count_polygons
                                scan_data.polygons_data.add_polygon(scan_data, num_of_polygons, [contours[0]], (x_1, y_1, x_1 + w_1, y_1 + h_1))
                                scan_data.polygons_data.add_polygon(scan_data, num_of_polygons + 1, [contours[1]], (x_2, y_2, x_2 + w_2, y_2 + h_2))
                                poly1 = scan_data.polygons_data.data[num_of_polygons]
                                poly2 = scan_data.polygons_data.data[num_of_polygons + 1]
                                poly_data_list_to_predict = [poly1, poly2]

                                scan_data.AnalyzeText.recognize_letters(scan_data, poly_data_list_to_predict, False,
                                                                        single_components_only_prediction=True)
                                # entropy_improvement = l_poly.entropy > np.average([p.entropy for p in poly_data_list])
                                if ((poly1.text_part.ocr_text == "ל" and poly2.text_part.ocr_text == missing_letter) or
                                    (poly2.text_part.ocr_text == "ל" and poly1.text_part.ocr_text == missing_letter)):
                                    if poly2.text_part.ocr_text == missing_letter:
                                        letter = poly2.text_part
                                        letter.set_orig_text(poly2.text_part.ocr_text, line_num)
                                        letter.ocr_index = letter_idx
                                        letter.orig_index = letter_idx
                                        word.sub_elements[letter_idx] = letter
                                        right_letter = poly1.text_part
                                        right_letter.set_orig_text(poly1.text_part.ocr_text, line_num)
                                        if letter_idx > 0:
                                            word.sub_elements[letter_idx - 1] = right_letter
                                        else:
                                            line.sub_elements[word_num - 1].sub_elements[-1] = right_letter
                                    if poly1.text_part.ocr_text == missing_letter: # todo - this my be redundant
                                        letter = poly1.text_part
                                        letter.set_orig_text(poly1.text_part.ocr_text, line_num)
                                        letter.ocr_index = letter_idx
                                        letter.orig_index = letter_idx
                                        word.sub_elements[letter_idx] = letter
                                        right_letter = poly2.text_part
                                        right_letter.set_orig_text(poly2.text_part.ocr_text, line_num)
                                        if letter_idx > 0:
                                            word.sub_elements[letter_idx - 1] = right_letter
                                        else:
                                            line.sub_elements[word_num - 1].sub_elements[-1] = right_letter

        scan_data.extended_ocr_text_data.assemble_full_text()
        MyDiffLib.update_words_errors_and_indices(scan_data)


    @staticmethod
    def missing_to_touching(scan_data: ScanData):
        for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word_num, word in enumerate(line.sub_elements):
                for letter_idx, letter in enumerate(word.sub_elements):
                    if letter.error_type == "MISSING_LETTER":
                    # if letter_idx < len(word.sub_elements) - 1 and letter.error_type == "MISSING_LETTER":
                        missing_letter = letter.get_orig_text(line_num=line_num)

                        if missing_letter == "י":
                            letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"

                        right_index = letter_idx - 1
                        left_index = letter_idx + 1

                        right_letter = word.sub_elements[right_index] if letter_idx > 0 else None
                        left_letter = word.sub_elements[left_index] if letter_idx < len(word.sub_elements) - 1 else None

                        right_letter_orig = right_letter.get_orig_text(line_num=line_num) if right_letter is not None else None
                        left_letter_orig = left_letter.get_orig_text(line_num=line_num) if left_letter is not None else None

                        # if right_letter_orig == missing_letter:
                        #     right_index = letter_idx - 2
                        #     right_letter = word.sub_elements[right_index] if letter_idx > 0 else None
                        #     right_letter_orig = right_letter.get_orig_text(line_num=line_num) if right_letter is not None else None
                        # if left_letter_orig == missing_letter:
                        #     left_index = letter_idx + 2
                        #     left_letter = word.sub_elements[left_index] if letter_idx < len(word.sub_elements) - 2 else None
                        #     left_letter_orig = left_letter.get_orig_text(line_num=line_num) if left_letter is not None else None

                        if right_letter_orig in lahaderet_letters or left_letter_orig in lahaderet_letters:
                                letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"

                        # right_letter = None
                        # if letter_idx > 0:
                        #     right_letter = word.sub_elements[letter_idx - 1]
                        # else:
                        #     if word_num > 0:
                        #         right_letter = line.sub_elements[word_num - 1].sub_elements[-1]
                        #     else:
                        #         right_letter = None
                        #
                        # left_letter = None
                        # if letter_idx < len(word.sub_elements) - 2:
                        #     left_letter = word.sub_elements[letter_idx + 1]
                        # else:
                        #     if word_num < len(line.sub_elements) - 2:
                        #         left_letter = line.sub_elements[word_num + 1].sub_elements[0]
                        #     else:
                        #         left_letter = None

                        _, missing_letter_typical_w = get_letter_median_sizes(scan_data, missing_letter)

                        if right_letter is not None and right_letter.ocr_text is not None:
                            _, right_letter_typical_w = get_letter_median_sizes(scan_data, right_letter.ocr_text)
                            norm_fac = normalized_factor(right_letter.w, right_letter_typical_w + missing_letter_typical_w, right_letter_typical_w)

                            if right_letter.ocr_text in lahaderet_letters or missing_letter in lahaderet_letters:
                                letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                # right_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                # if norm_fac >= 0.5:
                                #     letter.error_type = "TOUCHING_LETTER_H"
                                #     right_letter.error_type = "TOUCHING_LETTER_H"
                                #     ShowResults.handle_single_touching_letter_h(word, letter_idx - 1, letter_idx)
                                # else:
                                #     letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                #     right_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"

                            if right_letter.w > right_letter_typical_w:
                                if norm_fac >= 0.6:
                                    letter.error_type = "TOUCHING_LETTER_H"
                                    right_letter.error_type = "TOUCHING_LETTER_H"
                                    ShowResults.handle_single_touching_letter_h(word, right_index, letter_idx)
                                    continue
                                elif 0.2 <= norm_fac < 0.6:
                                    letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                    # right_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                else:
                                    # if right_letter.ocr_text in lahaderet_letters:
                                    #     letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                    #     right_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                    pass

                        if left_letter is not None and left_letter.ocr_text is not None:
                            _, left_letter_typical_w = get_letter_median_sizes(scan_data, left_letter.ocr_text)
                            norm_fac = normalized_factor(left_letter.w, left_letter_typical_w + missing_letter_typical_w, left_letter_typical_w)

                            if left_letter.ocr_text in lahaderet_letters or missing_letter in lahaderet_letters:
                                letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                # left_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                # if norm_fac >= 0.5:
                                #     letter.error_type = "TOUCHING_LETTER_H"
                                #     left_letter.error_type = "TOUCHING_LETTER_H"
                                #     ShowResults.handle_single_touching_letter_h(word, letter_idx, letter_idx + 1)
                                # else:
                                #     letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                #     left_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"

                            if left_letter.w > left_letter_typical_w:
                                if norm_fac >= 0.6:
                                    letter.error_type = "TOUCHING_LETTER_H"
                                    left_letter.error_type = "TOUCHING_LETTER_H"
                                    ShowResults.handle_single_touching_letter_h(word, letter_idx, left_index)
                                elif 0.2 <= norm_fac < 0.6:
                                    letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                    # left_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                else:
                                    # if left_letter.ocr_text in lahaderet_letters:
                                    #     letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                    #     left_letter.error_type = "MISSING_LETTER_OR_TOUCHING_LETTER_H"
                                    pass

    @staticmethod
    def handle_single_touching_letter_h(word: TextPart, blob_start, blob_end):
        """
        sets the first letter in the blob as erorr pseudo letter, and clears the errors of the rest of the letters in the blob
        sets the coordinated to the first letter to be the coordinates of the blob
        """
        touching_letter_blob_coords = ShowResults.get_union_coords(word.sub_elements[blob_start:blob_end + 1])
        for letter in word.sub_elements[blob_start:blob_end + 1]:
            letter.error_type = "TOUCHING_LETTER_H"
            letter.touching_letter_continuation = True
            letter.touching_letter_blob_coords = touching_letter_blob_coords
        word.sub_elements[blob_start].touching_letter_continuation = False

    @staticmethod
    def classify_distorted_yud(scan_data):
        entropies_list = []
        for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word in line.sub_elements:
                for letter_idx, letter in enumerate(word.sub_elements):
                    if letter.letter_class in ['y', 'y_tag'] and letter.error_type is None:
                        entropies_list.append(letter.poly_data.entropy)
                        # print(np.round(letter.poly_data.entropy, 4))
        entropy_threshold = np.mean(entropies_list) + 2 * np.std(entropies_list)  # we can also try percentile
        # entropy_threshold = np.percentile(entropies_list, 95)  # we can also try percentile
        for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word in line.sub_elements:
                for letter_idx, letter in enumerate(word.sub_elements):
                    if letter.letter_class in ['y', 'y_tag'] and letter.poly_data.entropy > entropy_threshold and letter.error_type is None:
                        letter.error_type = 'LETTER_SHAPE_CHANGED'

    # @staticmethod
    # def classify_distorted_ain(scan_data):
    #     entropies_list = []
    #     for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
    #         for word in line.sub_elements:
    #             for letter_idx, letter in enumerate(word.sub_elements):
    #                 if letter.letter_class in ['i', 'i_tag'] and letter.error_type is None:
    #                     entropies_list.append(letter.poly_data.entropy)
    #                     # print(np.round(letter.poly_data.entropy, 4))
    #     # entropy_threshold = np.mean(entropies_list) + 0.5 * np.std(entropies_list)  # we can also try percentile
    #     entropy_threshold = np.percentile(entropies_list, 90)  # we can also try percentile
    #     for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
    #         for word in line.sub_elements:
    #             for letter_idx, letter in enumerate(word.sub_elements):
    #                 if letter.letter_class in ['i', 'i_tag'] and letter.poly_data.entropy > entropy_threshold and letter.error_type is None:
    #                     letter.error_type = 'LETTER_SHAPE_CHANGED'

    @staticmethod
    def classify_distorted_alef(scan_data):
        entropies_list = []
        for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word in line.sub_elements:
                for letter_idx, letter in enumerate(word.sub_elements):
                    if letter.letter_class == 'a' and letter.error_type is None:
                        entropies_list.append(letter.poly_data.entropy)
                        # print(np.round(letter.poly_data.entropy, 4))
        entropy_threshold = np.mean(entropies_list) + 2 * np.std(entropies_list)  # we can also try percentile
        # entropy_threshold = np.percentile(entropies_list, 90)  # we can also try percentile
        for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word in line.sub_elements:
                for letter_idx, letter in enumerate(word.sub_elements):
                    if letter.letter_class == 'a' and letter.poly_data.entropy > entropy_threshold and letter.error_type is None:
                        letter.error_type = 'LETTER_SHAPE_CHANGED'

    @staticmethod
    def get_union_coords(letter_list):
        letter_list = [l for l in letter_list if l.poly_data is not None]
        x1, y1, x2, y2 = letter_list[0].poly_data.box.bounds
        for i in range(1, len(letter_list)):
            letter_list[i].error_type = None  # todo take this out of function?
            cur_x1, cur_y1, cur_x2, cur_y2 = letter_list[i].poly_data.box.bounds
            x1 = min(x1, cur_x1)
            y1 = min(y1, cur_y1)
            x2 = max(x2, cur_x2)
            y2 = max(y2, cur_y2)
        h = y2 - y1
        w = x2 - x1
        return x1, y1, h, w


    @staticmethod
    def estimate_single_missing_textpart_coordinates(scan_data, cur_textpart: TextPart, cur_textpart_i, parent_textpart: TextPart, avg_w):
        """
            estimates the coordinates of missing words/letters, based on the coordinates of the surrounding words/letters
        """
        xs = []
        ys = []
        ws = []
        hs = []
        closest_neighbors_idxs = []
        # get both neighbors
        for i in range(cur_textpart_i - 1, -1, -1):
            if parent_textpart.sub_elements[i].x is not None:
                closest_neighbors_idxs.append(i)
                break
        for i in range(cur_textpart_i + 1, len(parent_textpart.sub_elements)):
            if parent_textpart.sub_elements[i].x is not None:
                closest_neighbors_idxs.append(i)
                break
        # collect their stats:
        for adjacent_i in closest_neighbors_idxs:
            adjacent_textpart = parent_textpart.sub_elements[adjacent_i]
            xs.append(adjacent_textpart.x)
            ys.append(adjacent_textpart.y)
            ws.append(adjacent_textpart.w)
            hs.append(adjacent_textpart.h)
        # estimate the missing textpart's coordinates:
        if len(xs) == 2:
            cur_textpart.x = (xs[0] + (xs[1] + ws[1])) / 2  # set x to average:
            cur_textpart.x -= avg_w / 2  # move by half width:
            cur_textpart.y = np.average(ys)
            cur_textpart.h = np.average(hs)
            cur_textpart.w = avg_w
        elif len(xs) == 1:
            if cur_textpart_i == 0:  # if no previous textpart, set to the right of the first textpart
                cur_textpart.x = xs[0] + ws[0]
            else:
                cur_textpart.x = xs[0]
                cur_textpart.x -= avg_w  # move by width:
            cur_textpart.y = ys[0]
            cur_textpart.h = hs[0]
            cur_textpart.w = avg_w
        elif len(xs) == 0:
            cur_textpart.x = cur_textpart.y = cur_textpart.h = cur_textpart.w = 0
            return  # to not crash on closest_neighbors_idxs[0]
        page_width = scan_data.width
        shift = 0
        if cur_textpart.x < 0:
            shift = - cur_textpart.x
        elif cur_textpart.x + cur_textpart.w > page_width - 1:
            shift = page_width - cur_textpart.x - cur_textpart.w - 1
        cur_textpart.x += shift
        cur_textpart.x = int(cur_textpart.x)
        cur_textpart.y = int(cur_textpart.y)
        cur_textpart.h = int(cur_textpart.h)
        cur_textpart.w = int(cur_textpart.w)
