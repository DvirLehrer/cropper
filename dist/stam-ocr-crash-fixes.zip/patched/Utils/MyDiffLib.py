import difflib
from difflib import SequenceMatcher
from heapq import nlargest as _nlargest

import cv2
import diff_match_patch as dmp_module
import numpy as np

from Utils.DiffEntry import DiffType
from Utils.WordsIterator import PairedWordsIterator, get_sub_strings_list
from parameters import DEBUG_MODE, MAX_DISTANCE, parted_letters
from scipy.stats import entropy
from TextPart import TextPartType, TextPart

from Utils.common_methods import *
from letter_change import LetterChange, ChangeType


class MyDiffLib:

    @staticmethod
    def get_close_matches_indexes(word, possibilities, n=3, cutoff=0.1): #copied from difflib ( with modifications)
        """Use SequenceMatcher to return a list of the indexes of the best
        "good enough" matches. word is a sequence for which close matches
        are desired (typically a string).
        possibilities is a list of sequences against which to match word
        (typically a list of strings).
        Optional arg n (default 3) is the maximum number of close matches to
        return.  n must be > 0.
        Optional arg cutoff (default 0.6) is a float in [0, 1].  Possibilities
        that don't score at least that similar to word are ignored.
        """

        if not n > 0:
            raise ValueError("n must be > 0: %r" % (n,))
        if not 0.0 <= cutoff <= 1.0:
            raise ValueError("cutoff must be in [0.0, 1.0]: %r" % (cutoff,))
        result = []
        s = SequenceMatcher()
        s.set_seq2(word)
        for idx, x in enumerate(possibilities):
            s.set_seq1(x)
            if s.real_quick_ratio() >= cutoff and \
                    s.quick_ratio() >= cutoff and \
                    s.ratio() >= cutoff:
                result.append((s.ratio(), idx))

        # Move the best scorers to head of list
        result = _nlargest(n, result)

        # Strip scores for the best n matches
        return [x for score, x in result]

    @staticmethod
    def sequence_matcher(s1, s2):
        s = difflib.SequenceMatcher(lambda x: x == " ", s1, s2)
        # m = s.get_matching_blocks()
        o = s.get_opcodes()

        opcode_list = []
        # manupulations needed to turn s1 into s2 ==> s2 is the original word
        for tag, i1, i2, j1, j2 in o:
            if tag == 'replace':
                tag = DiffType.REPLACE
            elif tag == 'insert':
                tag = DiffType.INSERT
            elif tag == 'delete':
                tag = DiffType.DELETE
            else:  # op == 'equal'
                tag = DiffType.EQUAL
            # print('{:7}   s1[{}:{}] --> s2[{}:{}] {!r:>8} --> {!r}'.format(tag, i1, i2, j1, j2, s1[i1:i2], s2[j1:j2]))
            l = [tag, s1[i1:i2], s2[j1:j2]]
            opcode_list.append(l)

        # print (s.ratio())
        # pnina delete
        return s, opcode_list

    @staticmethod
    def print_dmp_results(lines_start_indices, words_state):
        # second scan to unite all entries per word
        print("original word : in ' ' ")
        print("compare result  : in () ")
        print("added ocr words : in [] ")

        last_line, last_word_index = lines_start_indices[-1]
        lines_start_indices_extended = lines_start_indices.copy()
        lines_start_indices_extended.append((last_line + 1, len(words_state)))
        for current_line, next_line in iter(zip(lines_start_indices_extended, lines_start_indices_extended[1:])):
            line_num, word_inedx = current_line
            n_line_num, n_word_inedx = next_line
            if word_inedx == n_word_inedx:
                print("empty line or error")
            print(f"{line_num}\n")
            for word in range(word_inedx, n_word_inedx):
                word_num, orig_word, diff_list = words_state[word]
                diff = " ".join([d.to_string() for d in diff_list])
                if word_num == -1:
                    print(f"[{diff}]")
                else:
                    print(f"'{orig_word}'({diff})")

    @staticmethod
    def compare_ocr_text_to_reference(compare_data_module):
        '''
        compare ocr_text with refernce text and build extended_ocr_text_data holding the combined data
        @param compare_data_module: data-structure that holds all data required for comparison of paragraphs
        @return:
        '''
        dmp = dmp_module.diff_match_patch()
        ocr_text = compare_data_module.ocr_text_data.ocr_text
        reference_text = compare_data_module.reference_text
        # todo future feature: use checklines=True and varify words are in right line
        # The data structure diffs_by_ops representing a diff is an array of tuples:
        # for example, let input be orig_text = "Hello world.", ocr_text = Goodbye world."
        # diffs_by_ops = [(DIFF_DELETE, "Hello"), (DIFF_INSERT, "Goodbye"), (DIFF_EQUAL, " world.")]
        # which means: delete "Hello", add "Goodbye" and keep " world."
        diffs_by_ops = dmp.diff_compute(reference_text, ocr_text, checklines=False, deadline=np.inf)
        dmp_op_to_difftype_dict = {
            dmp.DIFF_EQUAL: DiffType.EQUAL,
            dmp.DIFF_DELETE: DiffType.DELETE,
            dmp.DIFF_INSERT: DiffType.INSERT
        }

        if DEBUG_MODE:
            try:
                # for debug purpose
                html_result = dmp_module.diff_match_patch.diff_prettyHtml(dmp, diffs_by_ops)
                f = open('dmp_report.html', 'w', encoding='utf-8')
                f.write(html_result)
                f.close()
            except:
                print("html write failed, continuing")

        words_iter = PairedWordsIterator(ocr_text.split(), reference_text.split(), compare_data_module)

        diffs_by_ops.append((dmp.DIFF_EQUAL, ""))  # append to avoid loosing last diff while using "zip" later on
        diffs_by_ops_pairs = zip(diffs_by_ops, diffs_by_ops[1:])

        for current_diff, next_diff in diffs_by_ops_pairs:
            current_op, current_text = current_diff
            next_op, next_text = next_diff
            if current_text in {"", "\n"}:
                continue

            # replace case
            if (current_op, next_op) == (dmp.DIFF_DELETE, dmp.DIFF_INSERT) and next_text[0] != " ":  # todo check if necessary  next_text[0] != " "
                # compare diffs_by_ops and create replace entry
                if current_text[0] == " ":
                    diff_type_op = dmp_op_to_difftype_dict[current_op]
                    words_iter.add_diff(diff_type_op, orig_text=" ", ocr_text=None)
                    current_text = current_text.lstrip()
                if len(current_text) == 0:
                    words_iter.add_diff(DiffType.INSERT, orig_text=None, ocr_text=next_text)
                else:
                    if len(next_text) == 0:
                        raise Exception("error")
                    ocr_end_word = next_text[-1] == " "
                    if ocr_end_word:
                        next_text = next_text.rstrip()

                    orig_end_word = current_text[-1] == " "
                    if orig_end_word:
                        current_text = current_text.rstrip()

                    _, opcode_list = MyDiffLib.sequence_matcher(current_text, next_text)
                    for op, orig_text, ocr_text in opcode_list:
                        if op == DiffType.REPLACE:
                            orig_sub_strs = get_sub_strings_list(orig_text)
                            ocr_sub_strs = get_sub_strings_list(ocr_text)
                            if len(orig_sub_strs) > 1:
                                words_iter.add_diff(DiffType.DELETE, orig_text=" ".join(orig_sub_strs[:-1]) + " ", ocr_text=None)
                            # replace start
                            orig_text = orig_sub_strs[-1]
                            ocr_text = ocr_sub_strs[0]
                            ocr_length = len(ocr_text)
                            orig_length = len(orig_text)
                            if orig_length > ocr_length: # TODO: try add chopper here
                                missing_letters = orig_length - ocr_length
                                words_iter.add_diff(DiffType.DELETE, orig_text=orig_text[:missing_letters], ocr_text=None)
                                words_iter.add_diff(op, orig_text=orig_text[missing_letters:], ocr_text=ocr_text)
                            elif orig_length < ocr_length:
                                words_iter.add_diff(DiffType.REPLACE, orig_text=orig_text, ocr_text=ocr_text[:orig_length])
                                if orig_end_word:
                                    words_iter.add_diff(DiffType.DELETE, orig_text=" ", ocr_text=None)
                                    orig_end_word = False
                                words_iter.add_diff(DiffType.INSERT, orig_text=None, ocr_text=ocr_text[orig_length:])
                            else:
                                words_iter.add_diff(DiffType.REPLACE, orig_text=orig_text, ocr_text=ocr_text)
                            # replace end
                            if len(ocr_sub_strs) > 1:
                                words_iter.add_diff(DiffType.INSERT, orig_text=None, ocr_text=" " + " ".join(ocr_sub_strs[1:]))
                            # END

                        else:
                            words_iter.add_diff(op, orig_text=orig_text, ocr_text=ocr_text)
                    if ocr_end_word:
                        words_iter.add_diff(DiffType.INSERT, orig_text=None, ocr_text=" ")
                    if orig_end_word:
                        words_iter.add_diff(DiffType.DELETE, orig_text=" ", ocr_text=None)
                next(diffs_by_ops_pairs)
            #todo check opposite case: (current_op, next_op) == (dmp.DIFF_INSERT,dmp.DIFF_DELETE) or (current_op, next_op,current_op) ...
            else:
                diff_type_op = dmp_op_to_difftype_dict[current_op]
                curr_orig_text = current_text if current_op != dmp.DIFF_INSERT else None
                curr_ocr_text = current_text if current_op != dmp.DIFF_DELETE else None
                words_iter.add_diff(diff_type_op, orig_text=curr_orig_text, ocr_text=curr_ocr_text)

        words_iter.extended_ocr_text_data.assemble_full_text()
        #if scan_data.orig_text != words_iter.extended_ocr_text_data.orig_text:
        #    print("orig_text error")

    @staticmethod
    def insert_new_letter(current_word, right_index, left_index, new_text_part, line_num):
        '''
        insert new letter in current_word in the right place
        works only for letters in the close surrounding of current_index
        if one of the letters is "MISSING_LETTER"  and ocr text of new letter matches orig_text, update error_type to None
        if one of the letters is "LETTER_SHAPE_CHANGED" and ocr text of new letter matches orig_text, update error_type to "ADDED_LETTER" and add new letter without error.
        otherwise add new letter as added letter
        '''

        for i,letter_text_part in enumerate(current_word.sub_elements[right_index:left_index]):  # scan close letters
            if letter_text_part.error_type == "MISSING_LETTER" and \
                    letter_text_part.get_orig_text(line_num) == new_text_part.ocr_text:
                letter_text_part.error_type = new_text_part.error_type
                letter_text_part.copy_letter_ocr_data(new_text_part)
                return right_index +i
        for i,letter_text_part in enumerate(current_word.sub_elements[right_index:left_index]):  # scan close letters
            if letter_text_part.error_type == "LETTER_SHAPE_CHANGED" and \
                    letter_text_part.get_orig_text(line_num) == new_text_part.ocr_text:
                new_text_part.orig_index = letter_text_part.orig_index
                new_text_part.set_orig_text(letter_text_part.get_orig_text(line_num),line_num)
                letter_text_part.error_type = "ADDED_LETTER"
                letter_text_part.orig_index = None
                letter_text_part.set_orig_text(None, line_num)
                current_word.sub_elements.insert(right_index+i, new_text_part)
                return right_index + i
        new_text_part.error_type = "ADDED_LETTER"
        current_word.sub_elements.insert(right_index, new_text_part) # TODO  consider adding letter in different place
        return right_index





    @staticmethod
    def unite_letters_coords(letters):
        x_start, y_start = None, None
        x_end, y_end = None, None
        for letter in letters:
            # update coords
            if letter.x is not None:
                if x_start is None:
                    x_start, y_start = letter.x, letter.y
                    x_end, y_end = letter.x + letter.w, letter.y + letter.h
                else:
                    y_start = min(letter.y, y_start)
                    y_end = max(letter.y + letter.h, y_end)
                    x_start = min(x_start, letter.x)
                    x_end = max(x_end, letter.x + letter.w)
            # set_word_type
        return x_start, x_end, y_start, y_end

    @staticmethod
    def add_errors_by_geometry(scan_data, letter):
        poly_data = letter.poly_data
        if poly_data is None:
            return
        if poly_data.sh_polygon.geom_type == 'MultiPolygon':  # doesn't seem the new associator is getting into this if
            correct_contours_len = 1
            if letter.ocr_text in {'ה', 'ק'}:
                correct_contours_len = 2
            #todo - add back in or delete
            if False:  # len([c for c in poly_data.contours if cv2.contourArea(c) > 15]) > correct_contours_len :
                letter.error_type = "BROKEN_LETTER"
        if len(poly_data.lines) > 1 and letter.error_type != "OUT_OF_LINE_NOISE":
            letter.error_type = "TOUCHING_LETTER_V"
        return

    @staticmethod
    def update_words_errors_and_indices(scan_data):
        '''
        update words error types if exist and set word indices
        @param scan_data:
        @return:
        '''
        for line_i,line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word in line.sub_elements:
                x_start, x_end, y_start, y_end = MyDiffLib.unite_letters_coords(word.sub_elements)

                errors_found = False
                num_added = 0
                num_changed = 0
                num_touching = 0
                num_missing = 0
                for letter in word.sub_elements:  # set_word_type
                    MyDiffLib.add_errors_by_geometry(scan_data, letter)
                    if letter.error_type is not None and letter.error_type != "OUT_OF_LINE_NOISE":
                        errors_found = True
                    if letter.error_type == "ADDED_LETTER":
                        num_added += 1
                    elif letter.error_type == "LETTER_SHAPE_CHANGED":
                        num_changed += 1
                    elif letter.error_type == "MISSING_LETTER" or letter.error_type == "MISSING_LETTER_OR_TOUCHING_LETTER_H":
                    # elif letter.error_type == "MISSING_LETTER":
                        num_missing += 1
                    elif letter.error_type == "TOUCHING_LETTER_H":
                        num_touching += 1


                if x_start is not None:  # if not missing word
                    word.x = x_start
                    word.y = y_start
                    word.w = x_end - x_start
                    word.h = y_end - y_start

                MIN_MISTAKES_FOR_SWITCHED_WORD = 3
                # update opcodes and error type
                if errors_found:
                    if word.get_orig_text(line_i) == "":
                        word.error_type = "ADDED_WORD"
                    elif word.ocr_text == "":
                        word.error_type = "MISSING_WORD"
                    elif num_changed + num_added >= MIN_MISTAKES_FOR_SWITCHED_WORD:
                        word.error_type = "SWITCHED_WORD"
                    elif num_missing >= 2:
                        word.error_type = "SWITCHED_WORD"
                    elif num_missing > 0 and num_touching > 0:
                        word.error_type = "SWITCHED_WORD"
                    else:
                        word.error_type = "ALTERED_WORD"
                    _, word.opcode_list = MyDiffLib.sequence_matcher(word.ocr_text, word.get_orig_text(line_i))
                else:
                    word.error_type = None
        # self.scan_report_to_find_touching_letters(scan_data)
        scan_data.extended_ocr_text_data.update_indices()

    @staticmethod
    def check_touching_letters(scan_data):
        DEBUG_CHECK_TOUCHING_LETTERS = False
        def find_optional_indices_for_chopped_letters(current_word, x_left, x_right):
            '''
            find optional indices for polygon in current_word to be inserted.
            optional indices are those with x coordinates that does not overlap with the x coordinates of the new polygon or pass it from any side.
            more optional indices are those that has "missing letter" error_type and are close to optional indices.
            @param current_word:
            @return:
            '''

            x_center = (x_left+x_right)//2
            # find optional locations by x coordinate of new polygons
            left_index = len(current_word.sub_elements)
            right_index = 0

            for i, letter in enumerate(current_word.sub_elements):
                if letter.poly_data is not None:
                    if letter.x > x_center:
                        right_index = i + 1
                    else:
                        right_index = i - 1
                        break
            temp_right_index = max(right_index,0)  # save right_index for later use
            for i, letter in enumerate(reversed(current_word.sub_elements[0:right_index])):
                if letter.error_type == "MISSING_LETTER":
                    temp_right_index = right_index - i - 1
                else:
                    break
            right_index = temp_right_index
            for i, letter in enumerate(current_word.sub_elements[right_index + 1:]):
                if letter.poly_data is not None:
                    left_index = right_index + 1 + i
                    break

            for i, letter in enumerate(current_word.sub_elements[left_index + 1:]):
                if letter.error_type == "MISSING_LETTER":
                    left_index = left_index + 1 + i
                else:
                    break
            return left_index, right_index


        suspected_polygons_ids = set()
        initial_polygons_count = scan_data.polygons_data.count_polygons
        # collect polygons that are suspected to be touching letters
        for line_i, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word_i,word in enumerate(line.sub_elements):
                for letter_i,letter in enumerate(word.sub_elements):
                    # add polygons near missing letter to suspected as touching letters set (suspected_polygons_ids)
                    if letter.error_type == "MISSING_LETTER":
                        for current_index in [letter_i-1,letter_i+1]:
                            if current_index in range(0,len(word.sub_elements)):
                                near_letter = word.sub_elements[current_index]
                                poly_data = near_letter.poly_data
                                if poly_data is not None:
                                    if len(poly_data.lines) > 1:
                                        dprint("warning - detected multi line letter as candidate for touching letter next to missing letter. skipping, as multi errors in same letter to avoid complex buggy analysis, this is shown as error anyways. usually means heavy error before this.")
                                        continue
                                    entropy_threshold = 0.01  # 0.05 was too high
                                    if poly_data.entropy >= entropy_threshold or near_letter.error_type is not None:
                                        suspected_polygons_ids.add((poly_data, (line_i, word_i, current_index)))

        # chop all suspected polygons recursively, if polygon is chopped, it will be saved as two separate polygons in polygons_data
        touched_polygons = set()
        touched_words = set()
        while suspected_polygons_ids:
            orig_poly_data, poly_index_in_polygons_data = suspected_polygons_ids.pop()
            poly_id = orig_poly_data.id
            min_percentile_threshold_to_chop = -1
            result = scan_data.AnalyzeText.chop_polygon(scan_data, poly_id, None, touching_letters_test=True, min_gray_level_percentile_to_chop=min_percentile_threshold_to_chop)

            if result.chop_decision:
                local_touched_polygons = [(scan_data.polygons_data.get_by_index(index), poly_index_in_polygons_data) for index in result.touched_polygons]
                poly_data_list = scan_data.polygons_data.get_by_index(result.touched_polygons)
                if DEBUG_CHECK_TOUCHING_LETTERS:
                    import random
                    from Utils.common_methods import debug_show
                    im = scan_data.rgb_img.copy()
                    for cnt in orig_poly_data.contours:
                        cv2.drawContours(im, [cnt], -1, (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)), -1)
                    debug_show("orig_poly_data", im)
                    im = scan_data.rgb_img.copy()
                    for poly1 in poly_data_list:
                        cv2.drawContours(im, poly1.contours, -1, (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)), -1)
                    debug_show("poly_data_list", im)
                scan_data.AnalyzeText.recognize_letters(scan_data, poly_data_list, False, single_components_only_prediction=True)
                entropy_improvement = orig_poly_data.entropy > np.average([p.entropy for p in poly_data_list])
                if entropy_improvement:
                    suspected_polygons_ids.update(local_touched_polygons)
                    touched_polygons.update(local_touched_polygons)

                    line_i, word_i, _ = poly_index_in_polygons_data

                    # update word on extended_ocr_text_data
                    current_word = scan_data.extended_ocr_text_data.get_by_index((line_i, word_i))
                    curr_index = [i for i, letter in enumerate(current_word.sub_elements) if letter.poly_data and letter.poly_data.id == poly_id][0]
                    old_letter_text_part = current_word.sub_elements.pop(curr_index)
                    x_left = old_letter_text_part.x
                    x_right = x_left + old_letter_text_part.w

                    if old_letter_text_part.error_type != "ADDED_LETTER":  # text_part contains original letter that should be preserved
                        old_letter_text_part.error_type = "MISSING_LETTER"
                        old_letter_text_part.reset_letter_ocr_data()
                        current_word.sub_elements.insert(curr_index, old_letter_text_part)

                    left_index, right_index = find_optional_indices_for_chopped_letters(current_word, x_left, x_right)
                    poly_data_list.sort(key=lambda x: x.box.bounds[0], reverse=True)

                    max_percentile_threshold_to_show_error = 101
                    if result.score < max_percentile_threshold_to_show_error:
                        for poly in poly_data_list:
                            poly.text_part.error_type = "TOUCHING_LETTER_H"

                    right_index = 1 + MyDiffLib.insert_new_letter(current_word, right_index, left_index, poly_data_list[0].text_part, line_i)
                    MyDiffLib.insert_new_letter(current_word, right_index, left_index, poly_data_list[1].text_part, line_i)



                    scan_data.polygons_data.del_by_index(poly_id)
                    touched_words.add((line_i, word_i))
                else:
                    poly1, poly2 = result.touched_polygons
                    scan_data.polygons_data.del_by_index(poly1)
                    scan_data.polygons_data.del_by_index(poly2)



        for line_i, word_i in touched_words:
            # update extended_ocr_text_data with new added polygons and by touched_polygons

            current_word = scan_data.extended_ocr_text_data.get_by_index((line_i, word_i))
            # word_polygons_ids = [letter.poly_data.id for letter in current_word.sub_elements if letter.poly_data]
            # res_indices = scan_data.AnalyzeText.unite_parted_letters(scan_data, word_polygons_ids)
            # deleted_polygons = [polygon for polygon in word_polygons_ids if polygon not in res_indices]
            # if len(deleted_polygons) > 0:
            #     for letter in current_word:
            #         if letter.poly_data in deleted_polygons:
            #             current_word.sub_elements.remove(letter)
            current_word.assemble_full_text(line_i)

    @staticmethod
    def find_letters_to_join(scan_data):
        """
        unite broken letters and parted letters by context.
        first run only on added letters - check if they can be part of letters before and after them, and unite them with adequate error code (is the first broken letters mechanism adding error codes? there was one, but it seems canceled)
        if it's very small broken bit (like tagim) - consider not giving errors (for mezuzas with a lot of broken tagim false errors. liron said tagim don't matter for now (2023.10.24))
        """
        max_dist_to_attempt_unite = scan_data.typical_letter_diagonal / 8  # this prevents distant noises getting joined to letters.
        for line_i, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word_i, word in enumerate(line.sub_elements):
                for letter_i, letter in enumerate(word.sub_elements):
                    if letter.poly_data and len(letter.poly_data.lines) > 1:  # skip multi line letters
                        continue
                    # if letter.error_type in {"ADDED_LETTER", "LETTER_SHAPE_CHANGED"}:  # continue this - need to extend this to changed letters as well (and change where applicable)
                    if letter.error_type == "ADDED_LETTER":
                        letters_and_distances = []
                        poly = letter.poly_data
                        for neighbor_idx in range(letter_i-2, letter_i+3):  # can be extended to further letters, if we see this misses something. currently looking at two front and two back. one wasn't enough.
                            if neighbor_idx in range(len(word.sub_elements)) and neighbor_idx != letter_i:
                                neighbor_letter = word.sub_elements[neighbor_idx]
                                neighbor_poly = neighbor_letter.poly_data
                                if neighbor_poly and not neighbor_letter.error_type == "TOUCHING_LETTER_V" and len(neighbor_poly.lines) == 1:  # joining with multi line letters is undesirable (and very complicated)
                                    distance = poly.distance(neighbor_poly)
                                    intersection = poly.box.intersection(neighbor_poly.box).area
                                    overlap_min_ratio = intersection / min(poly.box.area, neighbor_poly.box.area)
                                    # discount the distance by half the overlap, to connect letters that are in the same rectangle more than neighbor letters. note - the real distance is used for broken letter classification later
                                    discounted_distance = (0.5 * distance + 0.5 * distance * (1-overlap_min_ratio))
                                    if discounted_distance < max_dist_to_attempt_unite:
                                        letters_and_distances.append([discounted_distance, distance, neighbor_idx])
                        if letters_and_distances:
                            _, closest_distance, closest_neighbor_idx = min(letters_and_distances, key=lambda x: x[0])
                            closest_neighbor_letter = word.sub_elements[closest_neighbor_idx]
                            # was_tag = MyDiffLib.clean_tagim(scan_data, letter, closest_neighbor_letter)
                            letters_and_ids = [[letter, (line_i, word_i, letter_i)], [closest_neighbor_letter, (line_i, word_i, closest_neighbor_idx)]]
                            scan_data.pending_changes.append(LetterChange(letters_and_ids, ChangeType.JOIN, closest_distance))

    @staticmethod
    def flush_pending_changes(scan_data):
        """
        run predictions on all the changed letters, choose if to keep the new letter or the old, apply changes, delete leftovers.
        start by implementing for joined letters, expand later for chops.
        """
        touched_ids = set()  # dirty bit list
        n = len(scan_data.pending_changes)
        new_polys = [None] * n
        old_polys_groups_list = [None] * n
        old_entropies_groups_list = [None] * n
        is_conflicting = [False] * n  # for skipping conflicts
        for change_idx, letter_change in enumerate(scan_data.pending_changes):
            polys = []
            entropies = []
            # check for conflicts:
            if any([input_letter.poly_data.id in touched_ids for input_letter, _ in letter_change.input_letters_and_ids]):
                is_conflicting[change_idx] = True
                continue
            for input_letter, _ in letter_change.input_letters_and_ids:
                poly = input_letter.poly_data
                debug_assert(poly)
                touched_ids.add(poly.id)
                polys.append(poly)
                entropies.append(poly.entropy)
            old_polys_groups_list[change_idx] = polys
            old_entropies_groups_list[change_idx] = entropies
            if letter_change.change_type == ChangeType.JOIN:
                debug_assert(len(polys) == 2)
                new_poly = scan_data.polygons_data.union(polys[0].id, polys[1].id, inplace=False, scan_data=scan_data)
                new_polys[change_idx] = new_poly
            else:
                raise Exception("not implemented yet ChangeType.CHOP flushing")

        # batch prediction:
        scan_data.AnalyzeText.recognize_letters(scan_data, [p for p in new_polys if p], False, single_components_only_prediction=False)

        for change_idx in reversed(range(n)):  # use reverse to solve indexes moving on changing lists
            if is_conflicting[change_idx]:
                continue
            old_entropy_mean = np.mean(old_entropies_groups_list[change_idx])
            new_poly = new_polys[change_idx]
            new_entropy = new_poly.entropy
            entropy_improvement = new_entropy < old_entropy_mean
            old_polys = old_polys_groups_list[change_idx]
            is_broken_tag = MyDiffLib.is_tag_brake(old_polys[0].text_part, old_polys[1].text_part, new_poly.text_part)
            apply_change = entropy_improvement or is_broken_tag
            if apply_change or is_broken_tag:
                letter_change = scan_data.pending_changes[change_idx]
                MyDiffLib.join_letters(scan_data, letter_change, old_polys, new_poly, is_broken_tag)
            else:  # not applying change
                scan_data.polygons_data.del_by_index(new_poly.id)
        scan_data.pending_changes = []  # reset
        return any(is_conflicting)

    @staticmethod
    def join_letters(scan_data, letter_change, old_polys, new_poly, is_broken_tag=False):
        '''
        currently this joins an added letter
        should this go in LetterChange class?
        '''
        line_idx = letter_change.input_letters_and_ids[0][1][0]
        word_idx = letter_change.input_letters_and_ids[0][1][1]
        added_letter_idx = letter_change.input_letters_and_ids[0][1][2]
        neighbor_letter_idx = letter_change.input_letters_and_ids[-1][1][2]
        word = scan_data.extended_ocr_text_data.get_by_index([line_idx, word_idx])

        # determine error code
        original_error_type = old_polys[1].text_part.error_type
        original_letter = old_polys[1].text_part.get_orig_text(line_idx)
        new_poly.text_part.set_orig_text(original_letter, line_idx)
        #if both are added letters:
        if original_error_type == "ADDED_LETTER":
            new_poly.text_part.error_type = "ADDED_LETTER"  # should be multiple errors, once we start using multiple errors
        elif new_poly.text_part.ocr_text != original_letter:
            new_poly.text_part.error_type = "LETTER_SHAPE_CHANGED"
        else:
            # future work - tune parameter MAX_DISTANCE.
            # future work - make something that inspects the seam's intensities, like in the chopper, to decide on error code.
            # if letter_change.distance > MAX_DISTANCE and new_poly.text_part.letter_class not in parted_letters and not is_broken_tag:
            # max distance deactivated, meaning broken letter detection sensitivity set to maximum
            if new_poly.text_part.letter_class not in parted_letters and not is_broken_tag:
                new_poly.text_part.error_type = "BROKEN_LETTER"
            elif original_error_type != "LETTER_SHAPE_CHANGED":
                new_poly.text_part.error_type = original_error_type
        new_letter = new_poly.text_part
        # note that letters order is not promised and there can be other letters between added and neighbor
        word.sub_elements[neighbor_letter_idx] = new_letter
        del word.sub_elements[added_letter_idx]
        word.assemble_full_text(line_num=line_idx)
        # cleanup:
        for old_poly in old_polys:
            scan_data.polygons_data.del_by_index(old_poly.id)

    @staticmethod
    def is_tag_brake(tag_suspect_letter, orig_letter, combined_letter):
        if orig_letter.ocr_text == combined_letter.ocr_text:
            letter_area = orig_letter.poly_data.sh_polygon.area
            tag_area = tag_suspect_letter.poly_data.sh_polygon.area
            area_factor = normalized_factor(tag_area, letter_area, letter_area * 0.1, smaller_better=True)
            tag_center_y = tag_suspect_letter.poly_data.center[1]
            letter_top = orig_letter.y
            letter_bottom = orig_letter.y + orig_letter.h
            aboveness_factor = normalized_factor(tag_center_y, letter_bottom, letter_top + 0.2 * orig_letter.h, smaller_better=True) # todo - check this works as expected
            tagness_score = area_factor * aboveness_factor
            tag_threshold = 0.9
            if tagness_score > tag_threshold:
                # dprint(f"ignoring tag on poly: {combined_letter.poly_data.id}")
                return True
        return False

    @staticmethod
    def fix_replace_cases(scan_data):
        def set_new_case(line_num, word, added_letter_index, missing_letter_index):
            if word.sub_elements[added_letter_index].ocr_text == word.sub_elements[missing_letter_index].get_orig_text(line_num):
                word.sub_elements[added_letter_index].error_type = None
            else:
                word.sub_elements[added_letter_index].error_type = "LETTER_SHAPE_CHANGED"
            orig_text = word.sub_elements[missing_letter_index].get_orig_text(line_num)
            word.sub_elements[added_letter_index].set_orig_text(orig_text, line_num)
            word.sub_elements[added_letter_index].orig_index = word.sub_elements[missing_letter_index].orig_index
            word.sub_elements.pop(missing_letter_index)

        for line_num, line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for word in line.sub_elements:
                prev_missing = False
                prev_added = False
                for letter_index, letter in enumerate(word.sub_elements):
                    if letter.error_type == 'ADDED_LETTER':
                        if prev_missing:
                            prev_added = False
                            prev_missing = False
                            set_new_case(line_num,word,letter_index, letter_index- 1)
                        else:
                            prev_added = True
                    elif letter.error_type == 'MISSING_LETTER':
                        if prev_added:
                            prev_added = False
                            prev_missing = False
                            set_new_case(line_num,word,letter_index-1, letter_index)
                        else:
                            prev_missing = True
                    else:
                        prev_added = False
                        prev_missing = False

    @staticmethod
    def calc_out_of_line_polygon_scores(scan_data, poly_data):
        cur_h, cur_w, median_h, median_w, foreground_clahe_median, background_clahe_median, perimeter_to_area_ratio, perimeter_to_area_index = poly_data.calc_polygon_metrics(scan_data)

        if median_h and median_w:
        # size scores:
            score_sufficient_h = normalized_factor(cur_h, median_h * 0.6, median_h * 0.3, low_score=0.2)
            score_sufficient_w = normalized_factor(cur_w, median_w * 0.6, median_w * 0.3, low_score=0.2)
            score_non_excessive_h = normalized_factor(cur_h, median_h * 3, median_h * 1.5, smaller_better=True)
            score_non_excessive_w = normalized_factor(cur_w, median_w * 3, median_w * 1.5, low_score=0.9, smaller_better=True)  # don't penalize long letters alot0, as they are legit
            score_size = score_sufficient_h * score_sufficient_w * score_non_excessive_h * score_non_excessive_w
        else:
            score_sufficient_h = score_sufficient_w = score_non_excessive_h = score_non_excessive_w = score_size = 1

        # entropy_scores:
        score_entropy = normalized_factor(poly_data.entropy, 2, 0.1, smaller_better=True, low_score=0.3)

        # color scores:
        if foreground_clahe_median:
            score_color = normalized_factor(foreground_clahe_median, background_clahe_median, background_clahe_median / 2, smaller_better=True)
        else:
            score_color = 1

        # thinness score
        score_thinness = normalized_factor(perimeter_to_area_index, 30, 20, smaller_better=True, low_score=0.7)

        poly_data.scores.final_score_out_of_line = score_size * score_entropy * score_color * score_thinness

        poly_data.scores.score_sufficient_h = score_sufficient_h
        poly_data.scores.score_sufficient_w = score_sufficient_w
        poly_data.scores.score_non_excessive_h = score_non_excessive_h
        poly_data.scores.score_non_excessive_w = score_non_excessive_w
        poly_data.scores.score_size = score_size
        poly_data.scores.score_entropy = score_entropy
        poly_data.scores.score_color = score_color
        poly_data.scores.score_thinness = score_thinness
        poly_data.scores.perimeter_to_area_index = perimeter_to_area_index

    @staticmethod
    def clean_out_of_line_noises(scan_data):
        '''
        remove noises that are out of line by iterating over the line from front and from back and as long as there is only  added letters they are out of text
        @param line:
        @return:
        '''
        update_median_stats_per_letter(scan_data)  # this is needed for the scores on multi contour letters
        for line in scan_data.extended_ocr_text_data.sub_elements:
            max_distance = scan_data.yud_w * 2

            all_new_letter = True
            added_letters_and_words_list_right = []
            for word_idx in range(len(line.sub_elements)):
                word = line.sub_elements[word_idx]
                for letter_idx in range(len(word.sub_elements)):
                    letter = word.sub_elements[letter_idx]
                    if letter.error_type == 'ADDED_LETTER':
                        added_letters_and_words_list_right.append((letter, word))
                        no_added_detected = False
                    else:  # found first letter that is not added
                        if letter.error_type not in ['MISSING_LETTER', 'NOISE', 'OUT_OF_LINE_NOISE', 'STEIN']:
                            for added_letter, _ in added_letters_and_words_list_right:
                                right_dist = added_letter.x - (letter.x + letter.w)
                                added_letter.distance_from_line = right_dist
                            all_new_letter = False
                            break
                if not all_new_letter:
                    break
            if all_new_letter:  #no original letters detected in line, might be line seperation issue
                print(f"warning - clean_out_of_line_noises found line with no ref, this means mistake in line separation or there is background noise above/bellow text. line: {line}")
                for added_letter, _ in added_letters_and_words_list_right:
                    added_letter.distance_from_line = np.inf

            added_letters_and_words_list_left = []
            if not all_new_letter: # if all new letter then it doesn't matter which way we iterate the line
                all_new_letter_so_far_left = True  # need to do again for a stopping condition. without this there is bugs. it's ok like this.
                for word_idx in range(len(line.sub_elements)-1, -1, -1):
                    word = line.sub_elements[word_idx]
                    for letter_idx in range(len(word.sub_elements)-1, -1, -1):
                        letter = word.sub_elements[letter_idx]
                        if letter.error_type == 'ADDED_LETTER':
                            added_letters_and_words_list_left.append((letter, word))
                        else:  # found first letter that is not added
                            if letter.error_type not in ['MISSING_LETTER', 'NOISE', 'OUT_OF_LINE_NOISE', 'STEIN']:
                                for added_letter, _ in added_letters_and_words_list_left:
                                    # calculate distance from added letter to letter:
                                    left_dist = letter.x - (added_letter.x + added_letter.w)
                                    added_letter.distance_from_line = left_dist
                                all_new_letter_so_far_left = False
                                break
                    if not all_new_letter_so_far_left:
                        break

            for added_letter, word in added_letters_and_words_list_right + added_letters_and_words_list_left:
                poly_data = added_letter.poly_data
                if poly_data is None:
                    print("got an empty poly_data in noise classification, should check this out (but can be ok, no panic)")
                else:
                    # if added_letter.distance_from_line > 0:  # to exclude cases where the noise overlaps / is a part of the edge letters
                        MyDiffLib.calc_out_of_line_polygon_scores(scan_data, poly_data)
                        distance_score = normalized_factor(added_letter.distance_from_line, scan_data.yud_w * 2, scan_data.yud_w, low_score=0.7, smaller_better=True)
                        # dprint(f"letter:\t {poly_data.text_part.ocr_text},\t score_size:\t {poly_data.scores.score_size:.2f},\t score_entropy:\t {poly_data.scores.score_entropy:.2f},\t score_color:\t {poly_data.scores.score_color:.2f},\t score:\t {poly_data.scores.final_score_out_of_line:.2f}")
                        # dprint(f"poly_data.scores.score_sufficient_h:\t{poly_data.scores.score_sufficient_h:2f},\t poly_data.scores.score_sufficient_w:\t{poly_data.scores.score_sufficient_w:2f},\t poly_data.scores.score_non_excessive_h:\t{poly_data.scores.score_non_excessive_h:2f},\t poly_data.scores.score_non_excessive_w:\t{poly_data.scores.score_non_excessive_w:2f}")
                        if distance_score * poly_data.scores.final_score_out_of_line < 0.5 and distance_score < 1:
                            TextPart.convert_letter_to_stain(scan_data, added_letter, word)
                            poly_data.text_part.error_type = 'OUT_OF_LINE_NOISE'

        # debug_save_poly_after_clean_out_of_line_noises = True
        if DEBUG and debug_save_poly_after_clean_out_of_line_noises:
            debug_save_all_polygons(scan_data, "5 - clean_out_of_line_noises")

    @staticmethod
    def post_noise_clean(scan_data):
        update_median_stats_per_letter(scan_data)
        debug_post_noise_clean = False
        if DEBUG and debug_post_noise_clean:
            print("debug post_noise_clean")
        for line in scan_data.extended_ocr_text_data.sub_elements:
            for word in line.sub_elements:
                for letter in word.sub_elements:  # set_word_type
                    if letter.error_type == 'ADDED_LETTER':
                        poly = letter.poly_data
                        score = MyDiffLib.calc_post_polygon_scores(scan_data, poly)
                        if score < 0.5:
                            if DEBUG and debug_post_noise_clean:
                                debug_save(f"poly_deleted_{poly.id}", poly.mask_255, scan_data_for_naming=scan_data)
                            scan_data.polygons_data.del_by_index(poly.id)
                            TextPart.convert_letter_to_noise(scan_data, poly.text_part, word)
        if DEBUG and debug_save_poly_after_post_noise_clean:
            debug_save_all_polygons(scan_data, "6 - post_noise_clean")

    @staticmethod
    def fix_touching_letter_v(scan_data):
        """
        fix touching letters between lines (vertically - TOUCHING_LETTER_V) by checking if letter detection is correct in one line and in the other there is no missing letters in that word - so
        in this case it implies that the letter is not needed in the other line and can remove it from there and remove the error
        """
        processed = set()
        for first_line_i, first_line in enumerate(scan_data.extended_ocr_text_data.sub_elements):
            for first_word_i, first_word in enumerate(first_line.sub_elements):
                for first_letter_i, first_letter in enumerate(first_word.sub_elements):
                    if first_letter not in processed and first_letter.poly_data and len(first_letter.poly_data.lines) == 2:  # doesn't work for 3 lines right now. if the need arises - develop and expand this
                        processed.add(first_letter)
                        found_second_letter = False
                        # search for touching letter in next line:
                        if first_line_i+1 in first_letter.poly_data.lines:
                            for second_word_i, second_word in enumerate(scan_data.extended_ocr_text_data.sub_elements[first_line_i+1].sub_elements):
                                for second_letter_i, second_letter in enumerate(second_word.sub_elements):
                                    if second_letter is first_letter:  # instance equation
                                        # found letter and other letter, now check where is belongs:
                                        found_second_letter = True
                                        processed.add(second_letter)
                                        words = [first_word, second_word]
                                        # letters = [first_letter, second_letter]
                                        letter = first_letter
                                        lines_idxs = [first_line_i, first_line_i+1]
                                        for i in [0, 1]:  # explanation: (i, 1-i) = (0,1) when i==0 and (1,0) when i==1
                                            missing_in_other_word = False
                                            for l in words[1-i].sub_elements:  # iterate other word:
                                                if l.error_type == "MISSING_LETTER":
                                                    missing_in_other_word = True
                                            correct_detection_in_this_letter = letter.get_orig_text(lines_idxs[i]) == letter.ocr_text
                                            no_orig_text_in_other_letter = letter.get_orig_text(lines_idxs[1-i]) is None
                                            if not missing_in_other_word and correct_detection_in_this_letter and no_orig_text_in_other_letter:
                                                # 1. find letter above (in the top line search polygonsdata.lines and find the poly for right/left)
                                                # 2. check if letter is ,תה,ד,ך....
                                                # 3. check overlap between them
                                                letter_id = letter.poly_data.id
                                                keep_error = False
                                                for idx, poly in enumerate(scan_data.polygons_data.lines.get(i - 1, [])):
                                                    if poly.id == letter_id:
                                                        _row = scan_data.polygons_data.lines.get(i - 1, [])
                                                        if not (0 < idx < len(_row) - 1):
                                                            continue
                                                        prev_poly = _row[idx - 1]
                                                        next_poly = _row[idx + 1]
                                                        poly_x1, poly_y1, poly_x2, poly_y2 = poly.box.bounds
                                                        for curr_poly in [prev_poly, next_poly]:
                                                            if curr_poly.text_part.letter_class in touching_v_problematic_letters:
                                                                curr_x1, curr_y1, curr_x2, curr_y2 = curr_poly.box.bounds
                                                                overlap_x = min(poly_x2, curr_x2) - max(poly_x1, curr_x1)
                                                                overlap_y = min(poly_y2, curr_y2) - max(poly_y1, curr_y1)
                                                                if overlap_y > 0 and overlap_x > 0:
                                                                    curr_poly.text_part.error_type = "TOUCHING_LETTER_V"
                                                                    keep_error = True
                                                        break
                                                #remove error code and remove from other word
                                                if not keep_error:
                                                    letter.error_type = None
                                                letter.poly_data.lines.remove(lines_idxs[i-1])
                                                words[i-1].sub_elements.remove(letter)
                                                break
                                        break
                                if found_second_letter:
                                    break

    @staticmethod
    def calc_post_polygon_scores(scan_data, poly_data):
        cur_h, cur_w, median_h, median_w, foreground_clahe_median, background_clahe_median, perimeter_to_area_ratio, perimeter_to_area_index = poly_data.calc_polygon_metrics(scan_data)

        if median_h and median_w:
        # size scores:
            score_sufficient_h = normalized_factor(cur_h, median_h * 0.6, median_h * 0.3, low_score=0.2)
            score_sufficient_w = normalized_factor(cur_w, median_w * 0.6, median_w * 0.3, low_score=0.2)
            score_non_excessive_h = normalized_factor(cur_h, median_h * 3, median_h * 1.5, smaller_better=True)
            score_non_excessive_w = normalized_factor(cur_w, median_w * 3, median_w * 1.5, low_score=0.9, smaller_better=True)  # don't penalize long letters alot0, as they are legit
            score_size = score_sufficient_h * score_sufficient_w * score_non_excessive_h * score_non_excessive_w
        else:
            score_sufficient_h = score_sufficient_w = score_non_excessive_h = score_non_excessive_w = score_size = 1

        # entropy_scores:
        # score_entropy = normalized_factor(poly_data.entropy, 2, 0.1, smaller_better=True, low_score=0.3)

        # color scores:
        # if poly_data.text_part.ocr_text in ['ס', 'ם']:  # these currently have the inside as part of the intensity, so calculations won't be exact
        #     score_color = 1
        # else:
            # normalized_intensities_percentile_25 = np.percentile(normalized_letter_intensities, 25)
        if foreground_clahe_median:
            score_color = normalized_factor(foreground_clahe_median, background_clahe_median, background_clahe_median / 2, smaller_better=True)
        else:
            score_color = 1

        # thinness score
        score_thinness = normalized_factor(perimeter_to_area_index, 30, 20, smaller_better=True, low_score=0.7)

        poly_data.scores.final_score_post_noise_clean = score_size * score_color * score_thinness

        poly_data.scores.score_sufficient_h = score_sufficient_h
        poly_data.scores.score_sufficient_w = score_sufficient_w
        poly_data.scores.score_non_excessive_h = score_non_excessive_h
        poly_data.scores.score_non_excessive_w = score_non_excessive_w
        poly_data.scores.score_size = score_size
        # poly_data.scores.score_entropy = score_entropy
        poly_data.scores.score_color = score_color
        poly_data.scores.score_thinness = score_thinness
        poly_data.scores.perimeter_to_area_index = perimeter_to_area_index

        return poly_data.scores.final_score_post_noise_clean

    # @staticmethod
    # def detect_and_ignore_tagim(scan_data):
    #     for line in scan_data.extended_ocr_text_data.sub_elements:
    #         for word in line.sub_elements:
    #             for letter in word.sub_elements:  # set_word_type
    #                 if letter.error_type == 'ADDED_LETTER':

    # todo - delete? is the extra space active?
    @staticmethod
    def check_stains_and_spaces_errors(scan_data):
        for line in scan_data.extended_ocr_text_data.sub_elements:
            for word in line.sub_elements:
                for letter in word.sub_elements:  # set_word_type
                    if letter.error_type == 'ADDED_LETTER':
                        poly_data = letter.poly_data
                        # disabling stains for now, as the noise classicication catches what is needed
                        # if poly_data is not None:
                            #continue denoising here - use calc_polygon_scores to determine poly noise class
                            # MyDiffLib.calc_polygon_scores(scan_data, poly_data)
                            # print(f"letter: {letter.ocr_text}, score_size: {poly_data.scores.score_size}, score_entropy: {poly_data.scores.score_entropy}, score_color: {poly_data.scores.score_color}, score_location: {poly_data.scores.score_location}, score: {poly_data.scores.final_score_out_of_line}")
                            #print the same, but up to two digits after the period. delimited with tabs so it'll be nice:
                            # print(f"letter:\t {letter.ocr_text},\t score_size:\t {poly_data.scores.score_size:.2f},\t score_entropy:\t {poly_data.scores.score_entropy:.2f},\t score_color:\t {poly_data.scores.score_color:.2f},\t score:\t {poly_data.scores.final_score_out_of_line:.2f}")

                            # entropy_threshold = 1
                            # if poly_data.entropy > entropy_threshold:
                            #     TextPart.convert_letter_to_stain(scan_data, letter, word)

                        if letter.letter_class is None:
                            letter.error_type = 'EXTRA SPACE BETWEEN LETTERS'

    @staticmethod
    def detect_errors_by_context(scan_data):
        '''
        - detect touching letters and use chopper
        - add_errors_by_geometry
        - noise classification with context
        - update words error (ADDED_WORD, MISSING_WORD, ALTERED_WORD)
        - update_indices
        @param scan_data:
        @return:
        '''
        toc("starting detect_errors_by_context")
        MyDiffLib.fix_replace_cases(scan_data)
        MyDiffLib.update_words_errors_and_indices(scan_data)
        MyDiffLib.clean_out_of_line_noises(scan_data)  # run first to reduce compute time from the rest?

        # this isn't a "while true" because the associator can currently repeatedly try to join two polygons without accepting the change while having a conflict.
        # this behavior might waste 0.5 seconds on hard examples, it's reasonable for now.
        MyDiffLib.update_words_errors_and_indices(scan_data)  # need to run this before associator to prevent associator from associating multi line letters
        max_associator_iterations = 5
        toc("before associator")
        # todo - add chopper to loop
        for i in range(max_associator_iterations):
            MyDiffLib.find_letters_to_join(scan_data)
            rerun = MyDiffLib.flush_pending_changes(scan_data)
            if not rerun:
                break
            if i == max_associator_iterations - 1:
                dprint(f"warning: ran associator for max_associator_iterations ({max_associator_iterations}) iterations. are there words with multiple breaks?")
        toc("after associator")
        MyDiffLib.fix_touching_letter_v(scan_data)
        MyDiffLib.update_words_errors_and_indices(scan_data)
        MyDiffLib.post_noise_clean(scan_data)
        dprint(f"ran associator for {i+1} iterations")
        #stains deactivated, finds only extra spaces (if extra spaces is active)
        MyDiffLib.check_stains_and_spaces_errors(scan_data)
        MyDiffLib.check_touching_letters(scan_data)  # move this to fix loop above (requires some code changes, also make predictions run in batch)
        # add mechanism to check of stains that make ר turn to ה etc.?
