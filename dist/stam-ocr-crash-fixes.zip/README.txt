Three crashes in Stam-OCR
=========================

Found while benchmarking a cropper against your engine on 157 real customer
images. Fourteen of them — 9% — produced no report at all, and every one died
inside the engine rather than in the cropper. No crop can prevent them: they
depend on where a letter sits in the text, not on the quality of the picture.

  Utils/MyDiffLib.py:831  fix_touching_letter_v   KeyError: -1                8 images
  PolygonsList.py:100     union                   AttributeError: 'NoneType'  5 images
  ShowResults.py:474      fix_l_swallowing        IndexError                  1 image

All three are an index that is not there. `create_scan` catches the exception
and returns None, so the whole scan is lost — not one letter misjudged, the
entire report.

What is in this zip
-------------------
Three files, each with the smallest change that prevents the exception. Nothing
else is altered: no threshold moved, no decision changed. Anywhere the code
previously crashed it now skips that check; anywhere it did not crash it behaves
exactly as before.

What was measured
-----------------
All 157 images were scored twice against the engine, once with these changes and
once without, and compared image by image — not just the error counts but which
fault was reported on which letter in which word:

  identical verdict      143      same faults, same letters, same places
  rescued                 14
  verdict changed          0
  broken                   0

  engine returned a result   91.1%  ->  100%
  text recovered from the
  known reference text       79.5%  ->  86.1%
  rough-parchment folder     54.6%  ->  75.2%

One thing left alone
--------------------
At MyDiffLib.py:831, `i` runs over [0, 1] and says which of the two lines a
letter spans; the line numbers themselves are in `lines_idxs`. The code reads
`polygons_data.lines[i - 1]`, which asks a dict for key -1 when i is 0 — the
crash. When i is 1 it does not crash, but it reads line 0, which is not the line
the letter touches either.

That looks like it was meant to be `lines_idxs[1 - i]`. It has NOT been changed
here, because that would alter what the engine decides and there was no way to
verify the intent from outside. Worth a look by whoever wrote it.
